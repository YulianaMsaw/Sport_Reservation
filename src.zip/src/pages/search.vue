<script setup>
import searchlist from '../components/searchlist.vue'
</script>

<template>
  <searchlist />
</template>
