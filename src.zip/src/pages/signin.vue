<script setup lang="ts">
import sign_panel from '../components/sign_panel.vue'
</script>

<template>
  <sign_panel />
</template>
