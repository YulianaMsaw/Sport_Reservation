<script setup lang="ts">
import registration_panel from '../components/registration_panel.vue'
</script>

<template>
  <registration_panel />
</template>
