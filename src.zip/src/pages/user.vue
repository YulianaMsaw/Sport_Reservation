<template>
  <div class="w-4/5 m-auto">
    <div class="flex gap-5 items-center my-5">
      <RouterLink to="/"> <img src="/back.png" alt="back" class="w-5 h-5" /></RouterLink>
      <p class="text-xl text-black text-bold font-bold">Личный кабинет</p>
    </div>
  </div>
</template>
