<script setup>
import editprofile from '../components/editprofile.vue'
</script>

<template>
  <editprofile />
</template>
