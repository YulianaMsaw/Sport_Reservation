<template>
  <div class="bg-zinc-950 border-t">
    <div class="w-4/5 m-auto">
      <div class="border-b border-slate-300 flex pt-10 pb-5">
        <div class="flex gap-5">
          <img src="/logo.png" alt="logo" />
          <p class="font-bold text-2xl text-slate-300 my-auto">SportTag</p>
        </div>
        <ul class="flex gap-10 text-slate-300 text-sm font-inter ml-auto text-slate-300 my-auto">
          <li class="cursor-pointer hover:text-sky-500">О Нас</li>
          <li class="cursor-pointer hover:text-sky-500">Контакты</li>
        </ul>
      </div>
      <div class="py-10">
        <ul class="flex gap-10 justify-end">
          <li class="cursor-pointer hover:text-sky-500">
            <img src="/instagram.png" alt="instagram" />
          </li>
          <li class="cursor-pointer hover:text-sky-500"><img src="/linkin.png" alt="linkin" /></li>
          <li class="cursor-pointer hover:text-sky-500">
            <img src="/facebook.png" alt="facebook" />
          </li>
          <li class="cursor-pointer hover:text-sky-500">
            <img src="/twitter.png" alt="twitter" />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
